from flask import Flask, request, redirect, url_for, render_template
import mysql.connector

app = Flask(__name__)

# MySQL connection
def get_db_connection():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",  # Replace with your MySQL username
        password="root",  # Replace with your MySQL password
        database="student_db"  # Replace with your database name
    )
    return conn

# Home Page (Student Search)
@app.route('/')
def home():
    return render_template('search.html')

# Add Student Page
@app.route('/add', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        reg_no = request.form['regNo']
        name = request.form['name']
        department = request.form['department']
        programme = request.form['programme']
        subject_code = request.form['subjectCode']
        internal_obtained = int(request.form['internalObtained'])
        internal_total = int(request.form['internalTotal'])
        external_obtained = int(request.form['externalObtained'])
        external_total = int(request.form['externalTotal'])
        total_marks = internal_obtained + external_obtained
        knowledge = int(request.form['knowledge'])
        understanding = int(request.form['understanding'])
        analyse = int(request.form['analyse'])
        evaluate = int(request.form['evaluate'])
        creative = int(request.form['creative'])

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO students (reg_no, name, department, programme, subject_code, internal_obtained, internal_total, external_obtained, external_total, total_marks, knowledge, understanding, analyse, evaluate, creative)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ''', (reg_no, name, department, programme, subject_code, internal_obtained, internal_total, external_obtained, external_total, total_marks, knowledge, understanding, analyse, evaluate, creative))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('home'))
    return render_template('add.html')

# Search Student
@app.route('/search', methods=['GET'])
def search_student():
    reg_no = request.args.get('regNo')
    department = request.args.get('department')
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT * FROM students WHERE reg_no = %s AND department = %s', (reg_no, department))
    subjects = cursor.fetchall()
    cursor.close()
    conn.close()
    if subjects:
        student = subjects[0]  # Use the first subject for student details
        return render_template('profile.html', student=student, subjects=subjects)
    return "Student not found!"

@app.route('/getSkills', methods=['GET'])
def get_skills():
    reg_no = request.args.get('regNo')
    subject_code = request.args.get('subjectCode')
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT knowledge, understanding, analyse, evaluate, creative FROM students WHERE reg_no = %s AND subject_code = %s', (reg_no, subject_code))
    skills = cursor.fetchone()
    cursor.close()
    conn.close()
    if skills:
        return skills
    return {}

if __name__ == '__main__':
    app.run(debug=True)