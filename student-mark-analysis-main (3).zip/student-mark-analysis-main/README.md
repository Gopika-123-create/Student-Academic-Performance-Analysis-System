# Student Mark Analysis System

A web application to analyze student marks and visualize skill distribution using Flask, MySQL, and Chart.js.

---

## Features

1. **Add Student**:
   - Enter student details (Register Number, Name, Department, Programme).
   - Enter subject-wise marks (Internal, External) and skill marks (Knowledge, Understanding, Analyse, Evaluate, Creative).

2. **Search Student**:
   - Search for a student by Register Number and Department.
   - View student details and subject-wise marks.

3. **Student Profile**:
   - Display student photo, details, and subject-wise marks.
   - Click on a subject code to view a **dynamic pie chart** for skill distribution.

---

## Technologies Used

- **Frontend**: HTML, CSS, JavaScript, Chart.js
- **Backend**: Python Flask
- **Database**: MySQL

---

## Setup Instructions

### 1. Prerequisites

- Python 3.x
- MySQL Server
- Flask (`pip install flask`)
- MySQL Connector (`pip install mysql-connector-python`)

### 2. Database Setup

1. Create a MySQL database named `student_db`.
   ```sql
   CREATE DATABASE student_db;
   USE student_db;